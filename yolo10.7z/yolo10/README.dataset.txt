# Safety Inspection > 2024-09-16 1:46pm
https://universe.roboflow.com/yolov8-zt64a/safety-inspection-ydaks

Provided by a Roboflow user
License: CC BY 4.0

